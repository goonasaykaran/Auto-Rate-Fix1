var Observable_1 = require('../../Observable');
var never_1 = require('../../observable/never');
Observable_1.Observable.never = never_1.InfiniteObservable.create;
//# sourceMappingURL=never.js.map