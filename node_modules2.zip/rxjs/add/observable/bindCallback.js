var Observable_1 = require('../../Observable');
var bindCallback_1 = require('../../observable/bindCallback');
Observable_1.Observable.bindCallback = bindCallback_1.BoundCallbackObservable.create;
//# sourceMappingURL=bindCallback.js.map