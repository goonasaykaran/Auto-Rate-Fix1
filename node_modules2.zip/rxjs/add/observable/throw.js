var Observable_1 = require('../../Observable');
var throw_1 = require('../../observable/throw');
Observable_1.Observable.throw = throw_1.ErrorObservable.create;
//# sourceMappingURL=throw.js.map