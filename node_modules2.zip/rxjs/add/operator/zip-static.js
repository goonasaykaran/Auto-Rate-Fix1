var Observable_1 = require('../../Observable');
var zip_static_1 = require('../../operator/zip-static');
Observable_1.Observable.zip = zip_static_1.zip;
//# sourceMappingURL=zip-static.js.map