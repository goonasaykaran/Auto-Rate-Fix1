var Observable_1 = require('../../Observable');
var merge_static_1 = require('../../operator/merge-static');
Observable_1.Observable.merge = merge_static_1.merge;
//# sourceMappingURL=merge-static.js.map