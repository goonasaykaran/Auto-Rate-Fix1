var Observable_1 = require('../../Observable');
var find_1 = require('../../operator/find');
var observableProto = Observable_1.Observable.prototype;
observableProto.find = find_1.find;
//# sourceMappingURL=find.js.map