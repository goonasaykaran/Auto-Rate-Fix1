var Observable_1 = require('../../Observable');
var inspectTime_1 = require('../../operator/inspectTime');
Observable_1.Observable.prototype.inspectTime = inspectTime_1.inspectTime;
//# sourceMappingURL=inspectTime.js.map