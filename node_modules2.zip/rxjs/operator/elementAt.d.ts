export declare function elementAt(index: number, defaultValue?: any): any;
