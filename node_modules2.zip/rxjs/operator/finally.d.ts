export declare function _finally<T>(finallySelector: () => void): any;
