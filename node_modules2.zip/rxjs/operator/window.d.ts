import { Observable } from '../Observable';
export declare function window<T>(closingNotifier: Observable<any>): Observable<Observable<T>>;
