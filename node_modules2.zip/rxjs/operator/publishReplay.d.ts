import { Scheduler } from '../Scheduler';
export declare function publishReplay(bufferSize?: number, windowTime?: number, scheduler?: Scheduler): any;
