import { Observable } from '../Observable';
export declare function dematerialize<T>(): Observable<any>;
