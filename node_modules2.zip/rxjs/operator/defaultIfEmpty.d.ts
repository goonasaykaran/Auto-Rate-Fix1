import { Observable } from '../Observable';
export declare function defaultIfEmpty<T, R>(defaultValue?: R): Observable<T> | Observable<R>;
