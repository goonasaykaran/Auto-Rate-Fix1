import { Scheduler } from '../Scheduler';
export declare function delay<T>(delay: number | Date, scheduler?: Scheduler): any;
