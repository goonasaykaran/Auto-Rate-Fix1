import { Observable } from '../Observable';
export declare function exhaust<T>(): Observable<T>;
