import { Observable } from '../Observable';
import { Scheduler } from '../Scheduler';
export declare function inspectTime<T>(delay: number, scheduler?: Scheduler): Observable<T>;
