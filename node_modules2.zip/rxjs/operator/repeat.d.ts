import { Observable } from '../Observable';
export declare function repeat<T>(count?: number): Observable<T>;
