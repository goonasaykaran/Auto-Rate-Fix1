export declare function isEmpty(): any;
