import { Scheduler } from '../Scheduler';
export declare function throttleTime<T>(delay: number, scheduler?: Scheduler): any;
