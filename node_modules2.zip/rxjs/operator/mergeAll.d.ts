import { Observable } from '../Observable';
export declare function mergeAll<R>(concurrent?: number): Observable<R>;
