import { Observable } from '../Observable';
export declare function _switch<T>(): Observable<T>;
