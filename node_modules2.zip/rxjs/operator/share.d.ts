import { Observable } from '../Observable';
export declare function share<T>(): Observable<T>;
