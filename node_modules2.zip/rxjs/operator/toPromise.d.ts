export declare function toPromise<T>(PromiseCtor?: PromiseConstructor): Promise<T>;
