import { Observable } from '../Observable';
export declare function sample<T>(notifier: Observable<any>): Observable<T>;
