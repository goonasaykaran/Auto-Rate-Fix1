import { Scheduler } from '../Scheduler';
export declare function timeout(due: number | Date, errorToSend?: any, scheduler?: Scheduler): any;
