export declare function publish(): any;
