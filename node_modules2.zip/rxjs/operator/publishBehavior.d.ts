export declare function publishBehavior(value: any): any;
