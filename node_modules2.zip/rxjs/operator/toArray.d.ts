export declare function toArray(): any;
