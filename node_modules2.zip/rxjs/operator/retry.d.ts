import { Observable } from '../Observable';
export declare function retry<T>(count?: number): Observable<T>;
