export declare function distinctUntilKeyChanged<T>(key: string, compare?: (x: any, y: any) => boolean): any;
