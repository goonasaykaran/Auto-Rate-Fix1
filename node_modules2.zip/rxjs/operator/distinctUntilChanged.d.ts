export declare function distinctUntilChanged<T>(compare?: (x: T, y: T) => boolean): any;
