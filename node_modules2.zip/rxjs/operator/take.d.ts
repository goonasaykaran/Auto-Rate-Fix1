export declare function take(total: any): any;
