export declare function ignoreElements(): any;
