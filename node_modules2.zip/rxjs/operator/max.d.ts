import { Observable } from '../Observable';
export declare function max<T, R>(comparer?: (x: R, y: T) => R): Observable<R>;
