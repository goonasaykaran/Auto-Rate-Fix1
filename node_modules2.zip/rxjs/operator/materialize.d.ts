import { Observable } from '../Observable';
import { Notification } from '../Notification';
export declare function materialize<T>(): Observable<Notification<T>>;
