import { Observable } from '../Observable';
export declare function min<T, R>(comparer?: (x: R, y: T) => R): Observable<R>;
