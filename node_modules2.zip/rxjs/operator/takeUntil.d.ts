import { Observable } from '../Observable';
export declare function takeUntil<T>(notifier: Observable<any>): any;
