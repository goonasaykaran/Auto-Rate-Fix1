export declare function skip(total: any): any;
