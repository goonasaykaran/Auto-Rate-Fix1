import { Observable } from '../Observable';
export declare function inspect<T>(notifier: Observable<any>): Observable<T>;
