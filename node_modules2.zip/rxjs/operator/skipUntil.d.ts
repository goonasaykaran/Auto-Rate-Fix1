import { Observable } from '../Observable';
export declare function skipUntil<T>(notifier: Observable<any>): Observable<T>;
