export * from 'angular2/src/mock/animation_builder_mock';
