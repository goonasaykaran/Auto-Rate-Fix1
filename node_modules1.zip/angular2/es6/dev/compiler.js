/**
 * @module
 * @description
 * Starting point to import all compiler APIs.
 */
export * from './src/compiler/url_resolver';
export * from './src/compiler/xhr';
export * from './src/compiler/compiler';
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY29tcGlsZXIuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyJhbmd1bGFyMi9jb21waWxlci50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTs7OztHQUlHO0FBQ0gsY0FBYyw2QkFBNkIsQ0FBQztBQUM1QyxjQUFjLG9CQUFvQixDQUFDO0FBQ25DLGNBQWMseUJBQXlCLENBQUMiLCJzb3VyY2VzQ29udGVudCI6WyIvKipcbiAqIEBtb2R1bGVcbiAqIEBkZXNjcmlwdGlvblxuICogU3RhcnRpbmcgcG9pbnQgdG8gaW1wb3J0IGFsbCBjb21waWxlciBBUElzLlxuICovXG5leHBvcnQgKiBmcm9tICcuL3NyYy9jb21waWxlci91cmxfcmVzb2x2ZXInO1xuZXhwb3J0ICogZnJvbSAnLi9zcmMvY29tcGlsZXIveGhyJztcbmV4cG9ydCAqIGZyb20gJy4vc3JjL2NvbXBpbGVyL2NvbXBpbGVyJzsiXX0=