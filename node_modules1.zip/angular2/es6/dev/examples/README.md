# API Examples

This folder contains small example apps that get in-lined into our API docs.
These examples are written with idiomatic TypeScript, and are not transpiled to Dart.
Each example contains tests for application behavior (as opposed to testing Angular's
behavior) just like an Angular application developer would write.
